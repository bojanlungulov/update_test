import _thread
import logging
import queue
import sys
import time
import uuid

import requests

from cloud_city.common.constants import TEMPERATURE_MEASUREMENT, TEMPERATURE_UNIT, PRESSURE_MEASUREMENT,\
    PRESSURE_UNIT, HUMIDITY_MEASUREMENT, HUMIDITY_UNIT, AQI_MEASUREMENT, AQI_UNIT, TVOC_MEASUREMENT, TVOC_UNIT, \
    ECO2_MEASUREMENT, ECO2_UNIT, AMBIENT_MEASUREMENT_TYPE, AIR_QUALITY_MEASUREMENT_TYPE, TIME_FORMAT
from cloud_city.common.daemon import Daemon
from cloud_city.devices.ambient import Ambient
from cloud_city.devices.device_factory import get_gps, get_camera, get_ens160
from cloud_city.reporting.utils import send_image_raw, send_sensors_data, send_log
from cloud_city.common.utils import unpack_image
from cloud_city.storage import storage
from cloud_city.common.utils import get_current_version
from cloud_city.settings import settings_utils

from cloud_city.server import logconfig

log = logging.getLogger(__name__)


def _add_measurement(data, created_at, lat, long, value, measurement_type, unit):
    payload = {
        "created_at": created_at,
        "device_id": 1,
        "lat": lat,
        "long": long,
        "type": measurement_type,
        "unit": unit,
        "value": value}

    data.append(payload)


def _send_ambient(data, session=None):
    log.info('SERVER Sending bme680')
    send_data = list()

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['temperature'],
                     TEMPERATURE_MEASUREMENT, TEMPERATURE_UNIT)

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['pressure'],
                     PRESSURE_MEASUREMENT, PRESSURE_UNIT)

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['humidity'],
                     HUMIDITY_MEASUREMENT, HUMIDITY_UNIT)

    result = send_sensors_data(send_data, session)

    if result is None:
        log.error('SERVER Device is not online')
    elif not result:
        log.info('SERVER Ambient measurement not sent, data dropped.')
    else:
        log.info('SERVER Ambient measurement uploaded successfully.')


def _send_air_quality(data, session=None):
    log.info('SERVER Sending air quality')
    send_data = list()

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['aqi'],
                     AQI_MEASUREMENT, AQI_UNIT)

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['tvoc'],
                     TVOC_MEASUREMENT, TVOC_UNIT)

    _add_measurement(send_data, data['time'], data['lat'], data['long'], data['eco2'],
                     ECO2_MEASUREMENT, ECO2_UNIT)

    result = send_sensors_data(send_data, session)

    if result is None:
        log.error('SERVER Device is not online')
    elif not result:
        log.info('SERVER Air quality measurement not sent, data dropped.')
    else:
        log.info('SERVER Air quality measurement uploaded successfully.')


class ServerDaemon(Daemon):
    def __init__(self, pidfile):
        super().__init__(pidfile)

        logconfig.init_logging()

        log.info(' ')
        log.info(' ')
        log.info(' ')
        log.info('********** Initialising Cloud City server daemon **********')
        log.info(' ')
        log.info(' ')
        log.info(' ')

        version = get_current_version()
        log.info(f'Current version {version}')
        log.info(' ')

        self._gps = get_gps()
        self._camera_device = get_camera()
        self._ambient = Ambient()
        self._air_quality = get_ens160()
        self._images_queue = queue.Queue(maxsize=0)
        self._measurement_queue = queue.Queue(maxsize=0)
        self._session = requests.Session()

        value = settings_utils.get_settings_option('save_images')
        self._save_images = value is not None and value
        if self._save_images:
            self._image_storage = storage.ImageStorage()
        log.info(f'SERVER saving images to filesystem is {"ON" if self._save_images else "OFF"}')

        value = settings_utils.get_settings_option('capture_image_interval')
        if value is not None:
            self._capture_image_interval = value
            log.info(f'SERVER capture image interval read from settings, value: {self._capture_image_interval} seconds')
        else:
            self._capture_image_interval = 1
            log.info(f'SERVER capture image interval not loaded from settings, setting default of 1 second.')

        value = settings_utils.get_settings_option('capture_sensors_interval')
        if value is not None:
            self._capture_sensors_interval = value
            log.info(f'SERVER capture sensors interval read from settings, value: {self._capture_sensors_interval} '
                     f'seconds')
        else:
            self._capture_sensors_interval = 30
            log.info(f'SERVER capture sensors interval not loaded from settings, setting default of 30 seconds.')

    def run(self):
        log.info('********** Starting Cloud City server daemon **********')
        self._gps.run()

        # send_log('Test log message')

        # Sleep for 5 seconds for camera to start.
        time.sleep(5)

        # Wait for GPS location to become valid and to be online.
        self._wait_location()

        _thread.start_new_thread(self.capture_camera, ())
        _thread.start_new_thread(self.capture_sensors, ())
        _thread.start_new_thread(self.send_image, ())
        _thread.start_new_thread(self.send_measurements, ())

        if self._save_images:
            self._image_storage.start()

        while True:
            # Do some processing.
            time.sleep(10)

    def _wait_location(self):
        # Wait for GPS location to become valid.
        log.info('SERVER Waiting for location fix.')
        while True:
            if self._gps.location_valid:
                log.info('SERVER Location is valid, starting measurement and reporting')
                break
            else:
                time.sleep(1)

    def _capture_image(self):
        timestamp = self._gps.timestamp
        lat = self._gps.latitude
        long = self._gps.longitude
        speed = self._gps.speed
        image_id = uuid.uuid4()
        log.debug(f'SERVER Capturing image with ID {image_id} at location: time {timestamp}, Lat: {lat}, Long: {long}, '
                  f'Speed: {speed}')
        result, image = self._camera_device.capture()
        if result:
            image = {
                'id': image_id,
                'time': timestamp.strftime(TIME_FORMAT),
                'lat': lat,
                'long': long,
                'speed': speed,
                'data': image
            }

            self._images_queue.put(image)
            log.debug(f'SERVER Added image to images queue: ID {image_id}, Latitude {lat}, Longitude: {long},'
                      f'Timestamp: {timestamp}, speed: {speed} km/h')

            if self._save_images:
                self._image_storage.insert_image(image)

        else:
            log.error('SERVER Failed to encode image to jpg.')

    def _capture_ambient(self):
        timestamp = self._gps.timestamp
        lat = self._gps.latitude
        long = self._gps.longitude

        temperature = self._ambient.get_temperature()
        pressure = self._ambient.get_pressure()
        humidity = self._ambient.get_humidity()

        if temperature is not None and pressure is not None and humidity is not None:
            ambient = {
                'type': AMBIENT_MEASUREMENT_TYPE,
                'time': timestamp.strftime(TIME_FORMAT),
                'lat': lat,
                'long': long,
                'temperature': temperature,
                'pressure': pressure,
                'humidity': humidity
            }

            self._measurement_queue.put(ambient)
            log.debug(f'SERVER Saved bme680: Time: {timestamp}, Latitude: {lat}, Longitude: {long}, '
                      f'Temperature: {temperature}, Pressure: {pressure}, humidity: {humidity}')

    def _capture_air_quality(self):
        timestamp = self._gps.timestamp
        lat = self._gps.latitude
        long = self._gps.longitude

        aqi = self._air_quality.get_aqi()
        tvoc = self._air_quality.get_tvoc()
        eco2 = self._air_quality.get_eco2()

        if aqi is not None and tvoc is not None and eco2 is not None:
            air_quality = {
                'type': AIR_QUALITY_MEASUREMENT_TYPE,
                'time': timestamp.strftime(TIME_FORMAT),
                'lat': lat,
                'long': long,
                'aqi': aqi,
                'tvoc': tvoc,
                'eco2': eco2
            }

            self._measurement_queue.put(air_quality)
            log.debug(f'SERVER Saved air quality: Time: {timestamp}, Latitude: {lat}, Longitude: {long}, '
                      f'AQI: {aqi}, TVOC: {tvoc}, ECO2: {eco2}')

    def _send_image(self):
        try:
            data = self._images_queue.get(block=False)

            image_id, time_stamp, lat, long, speed, image_data = unpack_image(data)
            log.info(f'SERVER Sending image with data: id {image_id}, time: {time_stamp}, lat: {lat}, long: {long} '
                     f'speed: {speed}')
            result = send_image_raw(image_id, time_stamp, lat, long, speed, image_data, self._session)

            if result is None:
                log.error('SERVER Device is not online')
            elif not result:
                log.info('SERVER Failed to upload image.')
            else:
                log.info('SERVER Image uploaded successfully')
        except queue.Empty:
            log.info('SERVER No images in queue.')
            time.sleep(1)

    def _send_sensors(self):
        try:
            data = self._measurement_queue.get(block=False)

            if data['type'] == AMBIENT_MEASUREMENT_TYPE:
                _send_ambient(data, self._session)
            elif data['type'] == AIR_QUALITY_MEASUREMENT_TYPE:
                _send_air_quality(data, self._session)
        except queue.Empty:
            log.info('SERVER No sensor measurements in queue.')

    def capture_camera(self):
        while True:
            if self._gps.location_valid:
                start = time.perf_counter()
                self._capture_image()
                duration = time.perf_counter() - start
                if duration < self._capture_image_interval:
                    time.sleep(self._capture_image_interval - duration)
            else:
                log.info('SERVER Location not valid, capturing data not possible.')
                self._wait_location()

    def capture_sensors(self):
        while True:
            if self._gps.location_valid:
                self._capture_ambient()
                self._capture_air_quality()
                time.sleep(self._capture_sensors_interval)
            else:
                log.info('SERVER Location not valid, capturing data not possible.')
                with self._measurement_queue.mutex:
                    self._measurement_queue.queue.clear()
                    log.info('SERVER Cleared measurements queue')

                self._wait_location()

    def send_image(self):
        while True:
            # Verify if device is online.
            # if not is_online('google.com'):
            #     log.info('Device is not online, skipping sending of data, waiting 10 seconds for next try')
            #     time.sleep(10)
            # else:
            # log.info('Device is online, sending images and measurements')

            start = time.perf_counter()
            self._send_image()
            # duration = time.perf_counter() - start
            # if duration < self._capture_image_interval:
            #     time.sleep(self._capture_image_interval - duration)

    def send_measurements(self):
        while True:
            # Verify if device is online.
            # if not is_online('google.com'):
            #     log.info('Device is not online, skipping sending of data, waiting 10 seconds for next try')
            #     time.sleep(10)
            # else:
            # log.info('Device is online, sending images and measurements')

            self._send_sensors()
            time.sleep(self._capture_sensors_interval)


def main(args=None):
    daemon = ServerDaemon('/var/run/src/server-daemon.pid')

    if len(args) == 2:
        if 'start' == args[1]:
            daemon.start()
        elif 'stop' == args[1]:
            daemon.stop()
        elif 'restart' == args[1]:
            daemon.restart()
        elif 'debug' == args[1]:
            daemon.run()
        else:
            print("Unknown command. Terminating.")
            print("Usage: %s start|stop|restart|debug" % args[0])
            return 2
        return 0
    else:
        print("usage: %s start|stop|restart|debug" % args[0])
        return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
