import logging
import logging.handlers
import os

MEASUREMENT_LOG_FILENAME = '/var/log/cloud-city/server.log'
REPORT_LOG_FILENAME = '/var/log/cloud-city/report.log'
CLOUD_CITY_LOGGER_NAME = 'cloud_city'


def init_logging():
    if not os.path.exists('/var/log/cloud-city'):
        os.makedirs('/var/log/cloud-city')

    root_log = logging.getLogger()

    server_log = logging.getLogger(CLOUD_CITY_LOGGER_NAME)

    if root_log.handlers:
        for handler in root_log.handlers:
            root_log.removeHandler(handler)

    if server_log.handlers:
        for handler in server_log.handlers:
            server_log.removeHandler(handler)

    backup_count = 5

    server_formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    server_handler = logging.handlers.RotatingFileHandler(MEASUREMENT_LOG_FILENAME, maxBytes=10485760,
                                                          backupCount=backup_count)
    server_handler.setFormatter(server_formatter)
    server_log.addHandler(server_handler)
    server_log.setLevel(logging.DEBUG)
