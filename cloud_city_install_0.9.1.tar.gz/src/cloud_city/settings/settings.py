settings = {
    'save_images': True,
    'capture_image_interval': 1,
    'capture_sensors_interval': 30,
    'sw_update_check_interval': 60,
}
