from . import settings


def get_settings_option(option):
    """Return settings option with provided name. None is returned if option is not present."""
    value = settings.settings.get(option)
    return value
