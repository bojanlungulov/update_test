import logging
import logging.handlers
import os

LOG_FILENAME = '/var/log/cloud-city/updater.log'
LOGGER_NAME = 'cloud_city'


def init_logging():
    if not os.path.exists('/var/log/cloud-city'):
        os.makedirs('/var/log/cloud-city')

    root_log = logging.getLogger()

    updater_log = logging.getLogger(LOGGER_NAME)

    if root_log.handlers:
        for handler in root_log.handlers:
            root_log.removeHandler(handler)

    if updater_log.handlers:
        for handler in updater_log.handlers:
            updater_log.removeHandler(handler)

    backup_count = 5

    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    handler = logging.handlers.RotatingFileHandler(LOG_FILENAME, maxBytes=10485760, backupCount=backup_count)
    handler.setFormatter(formatter)
    updater_log.addHandler(handler)
    updater_log.setLevel(logging.DEBUG)
