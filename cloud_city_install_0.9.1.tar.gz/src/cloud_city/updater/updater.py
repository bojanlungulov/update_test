import os.path
import sys
import logging
import time
import subprocess

from dotenv import load_dotenv
import git

from cloud_city.common.daemon import Daemon
from cloud_city.updater import logconfig
from cloud_city.common.utils import get_current_version
from cloud_city.settings import settings_utils

log = logging.getLogger(__name__)

REPOSITORY_URL = 'https://github.com/bojanlungulov/update_test.git'

REPOSITORY_DIRECTORY_DEVICE = '/home/pi/updates'
CODE_DIRECTORY_DEVICE = '/usr/local/bin/cloud-city'
REPOSITORY_DIRECTORY_DEVELOPMENT = '/Users/Bojan/updates'
CODE_DIRECTORY_DEVELOPMENT = '/Users/Bojan/cc-code'
REPOSITORY_NAME = 'update_test'

load_dotenv()

environment = os.getenv('RUN_PROFILE')


def _get_working_directory():
    if environment == 'development':
        return REPOSITORY_DIRECTORY_DEVELOPMENT
    else:
        return REPOSITORY_DIRECTORY_DEVICE


def get_repo():
    """Function that clones the repository. If the repository si cloned successfully path to the repository is returned.
    Else None."""

    working_directory = _get_working_directory()
    repo = None
    repo_path = os.path.join(working_directory, REPOSITORY_NAME)

    # Check if directory for code exists, if not create it
    if not os.path.exists(working_directory):
        os.makedirs(working_directory)
        log.info(f'Created working folder on location {working_directory}')
        repo = git.Repo.clone_from(REPOSITORY_URL, repo_path)
        log.info('Cloned repository from the remote')
    else:
        log.info('Repository already exists, skipped cloning')
        repo = git.Repo(repo_path)

    # Get the latest changes.
    repo.remotes.origin.pull()
    log.info(f'Pulled changes from the repo.')

    path = os.path.join(working_directory, REPOSITORY_NAME)
    return path


def get_version(file):
    # Remove extension
    name = file[:-7]

    # TODO: Add also git hash from the name once it is added to the name of the file.

    return name.split('_')[3]


def get_latest_version(repo):
    update_files = list()
    for file in os.listdir(repo):
        if 'cloud_city_install' in file:
            update_files.append(file)

    update_files.sort()

    max_version = '0.0.1'
    latest_version = None
    for file in update_files:
        version = get_version(file)
        if version > max_version:
            max_version = version
            latest_version = file

    return latest_version


def get_update_file(repo):
    update_file = None
    for file in os.listdir(repo):
        if 'cloud_city_install' in file:
            # Assumption is that there is only one update file in the repo.
            update_file = file
            break

    if update_file is not None:
        log.info(f'Found update file {update_file}')
    else:
        log.info(f'Update file not found')

    return update_file


def remove_old_files():
    directories = ['common', 'devices', 'reporting', 'server', 'settings', 'storage']

    for directory in directories:
        path = f'/usr/local/bin/cloud-city/{directory}'
        result = subprocess.run(['sudo', 'rm', '-rf', path], capture_output=True, text=True)
        log.debug(result.stdout)
        log.info(f'Removed {directory}')


def copy_new_files(source_path, destination_path):
    directories = ['common', 'devices', 'reporting', 'server', 'settings', 'storage']

    for directory in directories:
        source = f'{source_path}/{directory}/'
        destination = f'{destination_path}/{directory}'
        result = subprocess.run(['sudo', 'cp', source, destination], capture_output=True, text=True)
        log.debug(result.stdout)
        log.info(f'Removed {directory}')


def cleanup(path):
    directories = ['config', 'src']
    for directory in directories:
        result = subprocess.run(['sudo', 'rm', '-rf', f'{path}/{directory}'], capture_output=True, text=True)
        log.debug(result.stdout)
        log.info(f'Removed {directory}')


class UpdaterDaemon(Daemon):
    def __init__(self, pidfile):
        super().__init__(pidfile)

        logconfig.init_logging()

        log.info(' ')
        log.info(' ')
        log.info(' ')
        log.info('********** Initialising Cloud City updater daemon **********')
        log.info(' ')
        log.info(' ')
        log.info(' ')

        value = settings_utils.get_settings_option('sw_update_check_interval')
        if value is not None:
            self._update_check_interval = value
            log.info(f'SW update check interval read from settings, value: {self._update_check_interval} seconds')
        else:
            self._update_check_interval = 60
            log.info(f'SW update check interval not loaded from settings, setting default of 60 seconds.')

    def run(self):
        log.info('Starting updater process.')
        while True:
            repo_path = get_repo()
            file = get_update_file(repo_path)

            if file is None:
                log.info('Update file not found')
            else:
                current_version = get_current_version()
                received_version = get_version(file)
                update_file_path = os.path.join(repo_path, file)
                log.info(f'Repo path {repo_path}.')
                log.info(f'Update file found {update_file_path}.')
                log.info(f'Current SW version: {current_version}, received SW version: {received_version}')

                if received_version == current_version:
                    log.info('Received version is same as current version, skipping update.')
                else:
                    log.info('Received version is different from current version, performing update.')
                    result = subprocess.run(['sudo', 'systemctl', 'stop', 'cloud-city.service'],
                                            capture_output=True, text=True)
                    log.debug(result.stdout)
                    log.info('Executed command to stop cloud-city service.')

                    result = subprocess.run(['sudo', 'tar', '-xxf', update_file_path], capture_output=True,
                                            text=True)
                    log.debug(result.stdout)
                    log.info('Unpacked code archive')

                    # Remove old installed files
                    remove_old_files()

                    # Copy/sync new files
                    source = f'{repo_path}/src/'
                    destination = '/usr/local/bin/cloud-city/'
                    log.info(f'Syncing source: {source} to destination: {destination}')
                    # copy_new_files(source, destination)
                    result = subprocess.run(['sudo', 'rsync', '-avu', source, destination], capture_output=True, text=True)
                    log.debug(result.stdout)
                    log.info('Synced source files')

                    # Clean files
                    cleanup(repo_path)

                    # Reboot device
                    log.info('Rebooting device')
                    subprocess.run(['sudo', 'reboot'])

            log.info(f'Waiting for {self._update_check_interval} seconds before next check.')
            time.sleep(self._update_check_interval)


def main(args):
    daemon = UpdaterDaemon('/var/run/src/updater-daemon.pid')

    if len(args) == 2:
        if 'start' == args[1]:
            daemon.start()
        elif 'stop' == args[1]:
            daemon.stop()
        elif 'restart' == args[1]:
            daemon.restart()
        elif 'debug' == args[1]:
            daemon.run()
        else:
            print("Unknown command. Terminating.")
            print("Usage: %s start|stop|restart|debug" % args[0])
            return 2
        return 0
    else:
        print("usage: %s start|stop|restart|debug" % args[0])
        return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv))
