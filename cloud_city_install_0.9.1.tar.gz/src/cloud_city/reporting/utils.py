import os
import io
import json
import logging
import platform
import subprocess

import requests

from dotenv import load_dotenv

log = logging.getLogger(__name__)

BASE_URL = 'https://app.cloudcities.co/api'
POST_IMAGES_URL = BASE_URL + '/images'
POST_MEASUREMENT_URL = BASE_URL + '/sensor-events/bulk'
POST_LOG_URL = BASE_URL + '/devices/log'

load_dotenv()

token = os.getenv('TOKEN')


def is_online(host):
    param = '-n' if platform.system().lower() == 'windows' else '-c'
    # Building the command. Ex: "ping -c 1 google.com"
    command = ['ping', param, '1', host]

    log.info(f'REPORTING Pinging host {host} with the command {command}')

    response = subprocess.call(command, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    log.info(f'REPORTING Received response: {response}')

    return response == 0


def send_image(time, lat, long, speed, image, session=None):
    log.info('REPORTING Sending image with location data.')
    headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
    }

    files = {'image': open(image, 'rb')}

    payload = {
        'created_at': time,
        'lat': lat,
        'long': long,
        'speed': round(speed)
    }

    if session is None:
        log.debug(f'REPORTING Sending image with the parameters -> image: {image} data: {json.dumps(payload)}')
        response = requests.post(POST_IMAGES_URL, headers=headers, files=files, data=payload)
        log.info(f'REPORTING Received response: {response.status_code}')
    else:
        log.debug(f'Sending image with the session parameters -> image: {image} data: {json.dumps(payload)}')
        response = session.post(POST_IMAGES_URL, headers=headers, files=files, data=payload)
        log.info(f'REPORTING Received response: {response.status_code}')

    if response.status_code != 201:
        return False

    log.debug(f'REPORTING Received response data: {response.json()}')

    return True


def send_image_raw(image_id, time, lat, long, speed, image, session=None):
    log.info('REPORTING Sending raw image with location data.')
    headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
    }

    send_image_data = io.BytesIO(image)

    data = {'image': ('image.jpg', send_image_data)}

    payload = {
        'created_at': time,
        'lat': lat,
        'long': long,
        'speed': round(speed),
    }

    try:
        if session is None:
            log.debug(f'REPORTING Sending image with the ID: {image_id} to URL: {POST_IMAGES_URL}, '
                      f'and data: {json.dumps(payload)}')
            response = requests.post(POST_IMAGES_URL, headers=headers, files=image, data=payload)
        else:
            log.debug(f'REPORTING Sending image using session with the ID: {image_id} to URL: {POST_IMAGES_URL}, '
                      f'and data: {json.dumps(payload)}')
            response = session.post(POST_IMAGES_URL, headers=headers, files=data, data=payload)

        if response.status_code != 201:
            log.error(f'REPORTING Error in sending image, received response {response.status_code}')
            return False

        log.debug(f'REPORTING Received response data: {response.json()}')
        return True
    except requests.ConnectionError:
        log.exception('REPORTING Device not online.')
        return None


def send_sensors_data(measurements, session=None):
    headers = {'Content-Type': 'application/json',
               'Accept': 'application/json',
               'Authorization': 'Bearer ' + token
               }

    try:
        if session is None:
            log.debug(f'REPORTING Sending request to url: {POST_MEASUREMENT_URL}, total {len(measurements)} values.')
            response = requests.post(POST_MEASUREMENT_URL, headers=headers, data=json.dumps(measurements))
            log.info(f'REPORTING Response status code: {response.status_code}')
        else:
            log.debug(f'REPORTING Sending measurements with the session parameters')
            response = session.post(POST_MEASUREMENT_URL, headers=headers, data=json.dumps(measurements))
            log.info(f'REPORTING Received response: {response.status_code}')

        if response.status_code not in [200, 201]:
            return False
        else:
            log.debug(f'REPORTING Received response data: {response.json()}')
            return True
    except requests.ConnectionError:
        log.exception('REPORTING Device not online')
        return None


def send_log(message, session=None):
    log.info('REPORTING Sending log message.')
    headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer ' + token
    }

    try:
        if session is None:
            log.debug(f'REPORTING Sending log to url: {POST_LOG_URL}, message {message}')
            response = requests.post(POST_LOG_URL, headers=headers, data={'message': message})
            log.info(f'REPORTING Response status code: {response.status_code}')
        else:
            log.debug(f'REPORTING Sending log with the session parameters')
            response = session.post(POST_LOG_URL, headers=headers, data={'message': message})
            log.info(f'REPORTING Received response: {response.status_code}')

        if response.status_code not in [200, 201]:
            return False
        else:
            log.debug(f'REPORTING Received response data: {response.json()}')
            return True
    except requests.ConnectionError:
        log.exception('REPORTING Device not online')
        return None
