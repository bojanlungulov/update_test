import logging
import os
from pathlib import Path

from dotenv import load_dotenv

from .constants import IMAGES_FOLDER

log = logging.getLogger(__name__)

load_dotenv()

environment = os.getenv('RUN_PROFILE')


def delete_images():
    log.info(f'Deleting all images from {IMAGES_FOLDER} folder')

    for image in os.listdir(IMAGES_FOLDER):
        os.remove(os.path.join(IMAGES_FOLDER, image))

    log.info('Removed images')


def unpack_image(image):
    image_id = image['id']
    time_stamp = image['time']
    lat = image['lat']
    long = image['long']
    speed = image['speed']
    data = image['data']

    return image_id, time_stamp, lat, long, speed, data


def get_current_version():
    path = os.path.join(os.path.dirname(Path(__file__)), os.pardir, os.pardir, 'version')

    with open(path, 'r') as read_file:
        version = read_file.readline()

    return version
