IMAGES_FOLDER = '/var/log/cloud-city/images'

TIME_FORMAT = '%Y-%m-%d %H:%M:%S'

AMBIENT_MEASUREMENT_TYPE = 1
AIR_QUALITY_MEASUREMENT_TYPE = 2

TEMPERATURE_MEASUREMENT = 'temperature'
TEMPERATURE_UNIT = 'C'

PRESSURE_MEASUREMENT = 'pressure'
PRESSURE_UNIT = 'hPa'

HUMIDITY_MEASUREMENT = 'humidity'
HUMIDITY_UNIT = 'RH'

AQI_MEASUREMENT = 'aqi'
AQI_UNIT = ''

TVOC_MEASUREMENT = 'tvoc'
TVOC_UNIT = 'ppb'

ECO2_MEASUREMENT = 'eco2'
ECO2_UNIT = 'ppm'

# If location is not updated for more than this period (seconds), location is considered invalid.
TIME_FOR_DECLARING_LOCATION_INVALID = 5
