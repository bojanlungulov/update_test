import logging
import os
import sqlite3

from cloud_city.common.constants import DB_PATH

log = logging.getLogger(__name__)

CREATE_AMBIENT_TABLE = """
CREATE TABLE bme680 (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT,
    lat REAL,
    long REAL,
    temperature REAL,
    pressure REAL,
    humidity REAL,
    uploaded INTEGER
)
"""

CREATE_IMAGES_TABLE = """
CREATE TABLE images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT,
    lat REAL,
    long REAL,
    speed REAL,
    image TEXT,
    uploaded INTEGER
)
"""

CREATE_AIR_QUALITY_TABLE = """
CREATE TABLE air_quality (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    time TEXT,
    lat REAL,
    long REAL,
    aqi INTEGER,
    tvoc INTEGER,
    eco2 INTEGER,
    uploaded INTEGER
)
"""

INSERT_AMBIENT = """
INSERT INTO bme680 
    (time, lat, long, temperature, pressure, humidity, uploaded)
VALUES 
    ("%s", %s, %s, %s, %s, %s, 0)"""

INSERT_IMAGE = """
INSERT INTO images
    (time, lat, long, speed, image, uploaded)
VALUES
    ("%s", %s, %s, %s, "%s", 0)
"""

INSERT_AIR_QUALITY = """
INSERT INTO air_quality 
    (time, lat, long, aqi, tvoc, eco2, uploaded)
VALUES 
    ("%s", %s, %s, %s, %s, %s, 0)"""


SELECT_NOT_SEND_AMBIENT = """
SELECT * FROM bme680 WHERE uploaded = 0 ORDER BY id ASC
"""

SELECT_NOT_SEND_IMAGES = """
SELECT * FROM images WHERE uploaded = 0 ORDER BY id ASC
"""

SELECT_NOT_SEND_AIR_QUALITY = """
SELECT * FROM air_quality WHERE uploaded = 0 ORDER BY id ASC
"""

DELETE_IMAGE_BY_ID = """
DELETE FROM images WHERE id = %s
"""

SET_IMAGE_UPLOADED_BY_ID = """
UPDATE images SET uploaded = 1 WHERE id = %s
"""

SET_AMBIENT_UPLOADED_BY_ID = """
UPDATE bme680 SET uploaded = 1 WHERE id = %s
"""

SET_AIR_QUALITY_UPLOADED_BY_ID = """
UPDATE air_quality SET uploaded = 1 WHERE id = %s
"""

CLEAR_ALL_IMAGES = """
DELETE FROM images
"""

CLEAR_ALL_AMBIENT = """
DELETE FROM bme680
"""

CLEAR_ALL_AIR_QUALITY = """
DELETE FROM air_quality
"""

class Database:
    def __init__(self):
        create_table = True
        if os.path.exists(DB_PATH):
            create_table = False

        self._connection = sqlite3.connect(DB_PATH, isolation_level='EXCLUSIVE')
        self._cursor = self._connection.cursor()

        if create_table:
            self._create_db()

    def _execute_insert_query(self, query):
        with self._connection:
            self._cursor.execute(query)

    def _execute_select_query(self, query):
        with self._connection:
            self._cursor.execute(query)
            return self._cursor.fetchall()

    def _create_db(self):
        self._execute_insert_query(CREATE_AMBIENT_TABLE)
        self._execute_insert_query(CREATE_IMAGES_TABLE)
        self._execute_insert_query(CREATE_AIR_QUALITY_TABLE)

    def insert_ambient(self, time, lat, long, temperature, pressure, humidity):
        self._execute_insert_query(INSERT_AMBIENT % (time, lat, long, temperature, pressure, humidity))

    def insert_image(self, timestamp, lat, long, speed, image):
        self._execute_insert_query(INSERT_IMAGE % (timestamp, lat, long, speed, image))

    def insert_air_quality(self, time, lat, long, aqi, tvoc, eco2):
        self._execute_insert_query(INSERT_AIR_QUALITY % (time, lat, long, aqi, tvoc, eco2))

    def get_not_send_ambient(self):
        return self._execute_select_query(SELECT_NOT_SEND_AMBIENT)

    def get_not_send_images(self):
        return self._execute_select_query(SELECT_NOT_SEND_IMAGES)

    def get_not_send_air_quality(self):
        return self._execute_select_query(SELECT_NOT_SEND_AIR_QUALITY)

    def delete_image_by_id(self, image_id):
        self._execute_insert_query(DELETE_IMAGE_BY_ID % image_id)

    def set_image_uploaded_by_id(self, image_id):
        self._execute_insert_query(SET_IMAGE_UPLOADED_BY_ID % image_id)

    def set_ambient_uploaded_by_id(self, ambient_id):
        self._execute_insert_query(SET_AMBIENT_UPLOADED_BY_ID % ambient_id)

    def set_air_quality_uploaded_by_id(self, air_quality_id):
        self._execute_insert_query(SET_AIR_QUALITY_UPLOADED_BY_ID % air_quality_id)

    def clear_all_measurements(self):
        self._execute_insert_query(CLEAR_ALL_IMAGES)
        self._execute_insert_query(CLEAR_ALL_AMBIENT)
        self._execute_insert_query(CLEAR_ALL_AIR_QUALITY)
