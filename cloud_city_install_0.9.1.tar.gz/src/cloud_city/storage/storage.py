import logging
import os
import queue
import time

import cv2
import _thread

from cloud_city.common.constants import IMAGES_FOLDER
from cloud_city.common.utils import unpack_image

log = logging.getLogger(__name__)

LOG_KEY = 'IMAGESTORAGE'


def info(message):
    log.info(f'{LOG_KEY} {message}')


def debug(message):
    log.debug(f'{LOG_KEY} {message}')


def error(message, ex=None):
    if ex is None:
        log.error(f'{LOG_KEY} {message}')
    else:
        log.error(f'{LOG_KEY} {message}', ex)


class ImageStorage:
    def __init__(self):
        self._images_queue = queue.Queue(maxsize=0)

    def _save_thread(self):
        info('Save images thread started')
        while True:
            try:
                image = self._images_queue.get(block=False)
                image_id, time_stamp, lat, long, speed, image_data = unpack_image(image)
                # Save image on filesystem and then insert into db.
                info(f'Saving image with ID {image_id} to file system')
                start = time.perf_counter()
                file_name = f'{time_stamp.replace(":", "-")}_{lat}_{long}_{speed}_{image_id}.jpg'
                file_path = os.path.join(IMAGES_FOLDER, file_name)
                save_image = cv2.imdecode(image_data, 1)
                cv2.imwrite(file_path, save_image)
                debug(f'Saved image to file system with data: id {image_id}, time: {time_stamp}, lat: {lat}, '
                      f'long: {long} speed: {speed}')
                debug(f'image saved to file system in {time.perf_counter() - start}')
                debug(f'Number of images remained in the store queue {self._images_queue.qsize()}')

            except queue.Empty:
                info('No data in store images queue.')

            time.sleep(0.5)

    def insert_image(self, image):
        (image_id, lat, long, timestamp, speed, _) = unpack_image(image)
        self._images_queue.put(image)
        debug(f'Added image to store queue : ID {image_id}, Latitude {lat}, Longitude: {long}, '
              f'Timestamp: {timestamp}, speed: {speed} km/h')
        debug(f'Queue contains {self._images_queue.qsize()} images')

    def start(self):
        info('Starting image saver thread')
        _thread.start_new_thread(self._save_thread, ())
