from cloud_city.storage.database import Database


class Repository:
    def __init__(self):
        self._database = Database()

    def insert_ambient(self, time, lat, long, temperature, pressure, humidity):
        self._database.insert_ambient(time, lat, long, temperature, pressure, humidity)

    def insert_image(self, timestamp, lat, long, speed, image):
        self._database.insert_image(timestamp, lat, long, speed, image)

    def insert_air_quality(self, time, lat, long, aqi, tvoc, eco2):
        self._database.insert_air_quality(time, lat, long, aqi, tvoc, eco2)

    def clear_all_measurements(self):
        self._database.clear_all_measurements()

    def get_unsent_ambient(self):
        return self._database.get_not_send_ambient()

    def get_unsent_air_quality(self):
        return self._database.get_not_send_air_quality()

    def get_unsent_images(self):
        return self._database.get_not_send_images()

    def delete_image_by_id(self, image_id):
        self._database.delete_image_by_id(image_id)

    def set_image_uploaded_by_id(self, image_id):
        self._database.set_image_uploaded_by_id(image_id)

    def set_ambient_uploaded_by_id(self, measurements):
        for measurement in measurements:
            (ambient_id, _, _, _, _, _, _, _) = measurement
            self._database.set_ambient_uploaded_by_id(ambient_id)

    def set_air_quality_uploaded_by_id(self, measurements):
        for measurement in measurements:
            (air_quality_id, _, _, _, _, _, _, _) = measurement
            self._database.set_air_quality_uploaded_by_id(air_quality_id)
