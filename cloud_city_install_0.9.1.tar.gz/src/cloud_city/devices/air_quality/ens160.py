import logging

import RPi.GPIO as GPIO
import smbus

log = logging.getLogger(__name__)


class Ens160:
    def __init__(self):
        # Set enable pin high so device is operational
        self._initialized = False
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            GPIO.setup(17, GPIO.OUT)
            GPIO.output(17, GPIO.HIGH)

            self._address = 0x52
            self._i2c = smbus.SMBus(1)

            self._initialized = True
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error initializing ens160 sensor.')

    @property
    def initialized(self):
        return self._initialized

    def _read_byte(self, register):
        value = self._i2c.read_byte_data(self._address, register)
        return value

    def _read_data(self, register, length):
        value = self._i2c.read_i2c_block_data(self._address, register, length)
        return value

    def _write_byte(self, register, value):
        self._i2c.write_byte_data(self._address, register, value)

    def start(self):
        try:
            if self._initialized:
                self._write_byte(0x10, 0x02)
            else:
                log.error('ENS160 Sensor not initialized')
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error in communication with sensor.')
            return None

    def stop(self):
        try:
            if self._initialized:
                self._write_byte(0x10, 0x01)
            else:
                log.error('ENS160 Sensor not initialized')
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error in communication with sensor.')
            return None

    def get_aqi(self):
        try:
            if self._initialized:
                value = self._read_byte(0x21)
                return value
            else:
                log.error('ENS160 Sensor not initialized')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error in communication with sensor.')
            return None

    def get_tvoc(self):
        try:
            if self._initialized:
                value = self._read_data(0x22, 2)
                return value[1] * 256 + value[0]
            else:
                log.error('ENS160 Sensor not initialized')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error in communication with sensor.')
            return None

    def get_eco2(self):
        try:
            if self._initialized:
                value = self._read_data(0x24, 2)
                return value[1] * 256 + value[0]
            else:
                log.error('ENS160 Sensor not initialized')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('ENS160 Error in communication with sensor.')
            return None
