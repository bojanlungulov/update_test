import logging
import random

log = logging.getLogger(__name__)


class Ens160:
    def __init__(self):
        self._running = False

    def start(self):
        self._running = True

    def stop(self):
        self._running = False

    def get_aqi(self):
        return random.randint(1, 5)

    def get_tvoc(self):
        return random.randint(1, 20)

    def get_eco2(self):
        return random.randint(200, 300)
