import logging

import bme680

log = logging.getLogger(__name__)


class Bme680:
    def __init__(self):
        self._sensor = None
        try:
            self._sensor = bme680.BME680(bme680.I2C_ADDR_PRIMARY)
        except (RuntimeError, IOError):
            log.error('BME680 Error initializing on the primary address, trying secondary')
            try:
                self._sensor = bme680.BME680(bme680.I2C_ADDR_SECONDARY)
            except (RuntimeError, IOError, OSError):
                log.error('BME680 Error initializing on the secondary address.')

        if self._sensor is not None:
            self._sensor.set_humidity_oversample(bme680.OS_2X)
            self._sensor.set_pressure_oversample(bme680.OS_4X)
            self._sensor.set_temperature_oversample(bme680.OS_8X)
            self._sensor.set_filter(bme680.FILTER_SIZE_3)
            log.info('BME680 sensor initialized.')
        else:
            log.error('BME680 sensor not connected, check HW.')

    @property
    def initialized(self):
        return self._sensor is not None

    def get_temperature(self):
        try:
            if self.initialized and self._sensor.get_sensor_data():
                temperature = self._sensor.data.temperature
                log.debug(f'BME680 Measured temperature: {temperature}')
                return temperature
            else:
                log.error('BME680 Measurements from the sensor are not ready')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('BME680 Error in communication with sensor.')
            return None

    def get_pressure(self):
        try:
            if self.initialized and self._sensor.get_sensor_data():
                pressure = self._sensor.data.pressure
                log.debug(f'BME680 Measured pressure: {pressure}')
                return pressure
            else:
                log.error('BME680 Measurements from the sensor are not ready')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('BME680 Error in communication with sensor.')
            return None

    def get_humidity(self):
        try:
            if self.initialized and self._sensor.get_sensor_data():
                humidity = self._sensor.data.humidity
                log.debug(f'BME680 Measured humidity: {humidity}')
                return humidity
            else:
                log.error('BME680 Measurements from the sensor are not ready')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('BME680 Error in communication with sensor.')
            return None

    def get_measurements(self):
        try:
            if self.initialized and self._sensor.get_sensor_data():
                temperature = self._sensor.data.temperature
                pressure = self._sensor.data.pressure
                humidity = self._sensor.data.humidity
                log.debug(f'BME680 Measured temperature: {temperature}, pressure: {pressure}, humidity: {humidity}')
                return temperature, pressure, humidity
            else:
                log.error('BME680 Measurements from the sensor are not ready')
                return None
        except (RuntimeError, IOError, OSError):
            log.error('BME680 Error in communication with sensor.')
            return None
