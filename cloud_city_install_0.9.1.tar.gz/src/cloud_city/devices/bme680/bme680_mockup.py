import logging
import random

log = logging.getLogger(__name__)

TEMPERATURE_RANGE = 2000
PRESSURE_RANGE = 5000
HUMIDITY_RANGE = 3000


class Bme680:
    def __init__(self):
        # All values are in milli units
        self._temperature = 25000
        self._pressure = 1013000
        self._humidity = 30000
        self._initialized = True
        log.info('BME680 sensor initialized.')

    @property
    def initialized(self):
        return self._initialized

    def _get_temperature(self):
        return (self._temperature + random.randint(-1 * TEMPERATURE_RANGE, TEMPERATURE_RANGE)) / 1000

    def _get_pressure(self):
        return (self._pressure + random.randint(-1 * PRESSURE_RANGE, PRESSURE_RANGE)) / 1000

    def _get_humidity(self):
        return (self._humidity + random.randint(-1 * HUMIDITY_RANGE, HUMIDITY_RANGE)) / 1000

    def get_temperature(self):
        if self._initialized:
            temperature = self._get_temperature()
            log.debug(f'Measured temperature: {temperature}')
            return temperature
        else:
            log.error('Measurements from the sensor are not ready')
            return None

    def get_pressure(self):
        if self._initialized:
            pressure = self._get_pressure()
            log.debug(f'Measured pressure: {pressure}')
            return pressure
        else:
            log.error('Measurements from the sensor are not ready')
            return None

    def get_humidity(self):
        if self._initialized:
            humidity = self._get_humidity()
            log.debug(f'Measured humidity: {humidity}')
            return humidity
        else:
            log.error('Measurements from the sensor are not ready')
            return None

    def get_measurements(self):
        if self._initialized:
            temperature = self._get_temperature()
            pressure = self._get_pressure()
            humidity = self._get_humidity()
            log.debug(f'Measured temperature: {temperature}, pressure: {pressure}, humidity: {humidity}')
            return temperature, pressure, humidity
        else:
            log.error('Measurements from the sensor are not ready')
            return None
