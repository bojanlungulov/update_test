import logging
import os

import serial
from dotenv import load_dotenv

from cloud_city.devices.gps import neo_6_max
from cloud_city.devices.gps import neo_6_max_mockup

log = logging.getLogger(__name__)

load_dotenv()

environment = os.getenv('RUN_PROFILE')
simulate_location = os.getenv('SIMULATE_LOCATION')


def get_gps():
    gps = None
    simulate = simulate_location is not None and simulate_location == 'true'
    log.info(f'FACTORY Run env: {environment}, location simulation: {"enabled" if simulate else "disabled"}.')
    if environment == 'development':
        gps = neo_6_max_mockup.Neo6Max()
    elif (environment == 'device' or environment == 'device64') and simulate:
        gps = neo_6_max_mockup.Neo6Max()
    elif environment == 'device' or environment == 'device64':
        serial_port = serial.Serial("/dev/ttyS0", 9600, timeout=0.5)
        gps = neo_6_max.Neo6Max(serial_port.readline, serial_port.reset_input_buffer)

    return gps


def get_camera():
    camera_instance = None
    if environment == 'development':
        from .camera import camera_mockup
        camera_instance = camera_mockup.Camera()
    elif environment == 'device':
        from .camera import camera
        camera_instance = camera.Camera()

    return camera_instance


def get_bme680():
    bme_680 = None
    if environment == 'development':
        from .bme680 import bme680_mockup
        bme_680 = bme680_mockup.Bme680()
    elif environment == 'device':
        from .bme680 import bme680
        bme_680 = bme680.Bme680()

    return bme_680


def get_ens160():
    ens160 = None
    if environment == 'development':
        from .air_quality import ens160_mockup
        ens160 = ens160_mockup.Ens160()
    elif environment == 'device':
        from .air_quality import ens160
        ens160 = ens160.Ens160()

    return ens160

