import logging

from cloud_city.devices import device_factory

log = logging.getLogger(__name__)


class Ambient:
    def __init__(self):
        log.info('Initializing bme680 measurement class.')
        self._sensor = device_factory.get_bme680()

        self._initialized = self._sensor.initialized

        if not self._initialized:
            log.error('Ambient measurement not available')

    def get_temperature(self):
        return self._sensor.get_temperature()

    def get_humidity(self):
        return self._sensor.get_humidity()

    def get_pressure(self):
        return self._sensor.get_pressure()

