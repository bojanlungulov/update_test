import logging

import cv2
import numpy as np
from picamera2 import Picamera2


log = logging.getLogger(__name__)


class Camera:
    def __init__(self):
        self._camera = Picamera2()
        self._camera.configure(
            self._camera.create_preview_configuration(main={"format": "XRGB8888", "size": (1280, 960)})
        )

        self._camera.start()
        log.info('CAMERA Camera initialized')

    def _letterbox(self, im, new_shape=(320, 320), color=(114, 114, 114), auto=True, scale_fill=False, scaleup=True,
                   stride=32):
        # Resize and pad image while meeting stride-multiple constraints
        shape = im.shape[:2]  # current shape [height, width]
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        # Scale ratio (new / old)
        r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
        if not scaleup:  # only scale down, do not scale up (for better val mAP)
            r = min(r, 1.0)

        # Compute padding
        ratio = r, r  # width, height ratios
        new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
        dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
        if auto:  # minimum rectangle
            dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
        elif scale_fill:  # stretch
            dw, dh = 0.0, 0.0
            new_unpad = (new_shape[1], new_shape[0])
            ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

        dw /= 2  # divide padding into 2 sides
        dh /= 2

        if shape[::-1] != new_unpad:  # resize
            im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        im = cv2.copyMakeBorder(
            im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color
        )  # add border
        return im, ratio, (dw, dh)

    def _resize(self, input_image, img_size):
        """
        Args:
            input_image: cv2 image (np array)
            img_size: target size (int)

        Returns:
            CV2 np array with transformed image suitable for model
        """
        image = self._letterbox(input_image, new_shape=img_size, auto=False)[0]
        image = np.ascontiguousarray(image)

        return image

    def capture(self):
        log.info('CAMERA Capturing raw image')
        image = self._camera.capture_array()
        log.info('CAMERA Resizing image')
        resized = self._resize(image, 640)
        log.info('CAMERA Rotating image')
        rotated = cv2.rotate(resized, cv2.ROTATE_180)

        log.info('CAMERA Encoding image')
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]
        result, jpg_image = cv2.imencode('.jpg', rotated, encode_param)
        log.info('CAMERA Captured image')

        return result, jpg_image

