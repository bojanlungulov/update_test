import logging
import os
import uuid
import cv2
import numpy as np
from pathlib import Path

from PIL import Image

from cloud_city.common.constants import IMAGES_FOLDER

log = logging.getLogger(__name__)


class Camera:
    def __init__(self):
        self._first_file = os.path.join(os.path.dirname(Path(__file__)), os.path.pardir, os.path.pardir, os.path.pardir,
                                        os.path.pardir, 'resources', 'camera_mockup_001.jpg')
        self._second_file = os.path.join(os.path.dirname(Path(__file__)), os.path.pardir, os.path.pardir,
                                         os.path.pardir, os.path.pardir, 'resources',
                                         'camera_mockup_002.jpg')
        log.info('Camera initialized with resolution 1280x960')
        self._index = 0

    def capture(self, time=None):
        if time is not None:
            file_name = f'{time.strftime("%Y-%m-%d-%H-%M-%S")}_{uuid.uuid4()}.jpg'
        else:
            file_name = f'{uuid.uuid4()}.jpg'

        destination = os.path.join(IMAGES_FOLDER, file_name)

        if self._index == 0:
            mockup_image = self._first_file
            self._index += 1
        else:
            mockup_image = self._second_file
            self._index = 0

        with Image.open(mockup_image) as image:
            log.info('Resizing image')
            resized = image.resize((640, 640), resample=2)
            resized.save(destination)

        log.info('Saved image')
        return file_name

    def _letterbox(self, im, new_shape=(320, 320), color=(114, 114, 114), auto=True, scale_fill=False, scaleup=True,
                   stride=32):
        # Resize and pad image while meeting stride-multiple constraints
        shape = im.shape[:2]  # current shape [height, width]
        if isinstance(new_shape, int):
            new_shape = (new_shape, new_shape)

        # Scale ratio (new / old)
        r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
        if not scaleup:  # only scale down, do not scale up (for better val mAP)
            r = min(r, 1.0)

        # Compute padding
        ratio = r, r  # width, height ratios
        new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
        dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]  # wh padding
        if auto:  # minimum rectangle
            dw, dh = np.mod(dw, stride), np.mod(dh, stride)  # wh padding
        elif scale_fill:  # stretch
            dw, dh = 0.0, 0.0
            new_unpad = (new_shape[1], new_shape[0])
            ratio = new_shape[1] / shape[1], new_shape[0] / shape[0]  # width, height ratios

        dw /= 2  # divide padding into 2 sides
        dh /= 2

        if shape[::-1] != new_unpad:  # resize
            im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
        top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
        left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
        im = cv2.copyMakeBorder(
            im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color
        )  # add border
        return im, ratio, (dw, dh)

    def _resize(self, input_image, img_size):
        """
        Args:
            input_image: cv2 image (np array)
            img_size: target size (int)

        Returns:
            CV2 np array with transformed image suitable for model
        """
        image = self._letterbox(input_image, new_shape=img_size, auto=False)[0]
        image = np.ascontiguousarray(image)

        return image

    def capture(self):
        if self._index == 0:
            mockup_image = self._first_file
            self._index += 1
        else:
            mockup_image = self._second_file
            self._index = 0

        image = cv2.imread(mockup_image, 1)

        log.info('Resizing image')
        resized = self._resize(image, 640)
        log.info('Blurring image')

        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 90]
        result, jpg_image = cv2.imencode('.jpg', resized, encode_param)
        log.info('Encoded image to jpg')

        return result, jpg_image
