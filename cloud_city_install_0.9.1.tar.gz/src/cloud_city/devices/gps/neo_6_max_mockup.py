import logging
from datetime import datetime

log = logging.getLogger(__name__)


class Neo6Max(object):
    def __init__(self):
        self._location_valid = True
        self._latitude = 45.255136
        self._longitude = 19.845044
        self._ground_speed = 55
        self._timestamp = datetime.now().replace(microsecond=0)
        self._running = True

    @property
    def location_valid(self):
        return self._location_valid

    @property
    def latitude(self):
        return self._latitude

    @property
    def longitude(self):
        return self._longitude

    @property
    def speed(self):
        return self._ground_speed

    @property
    def timestamp(self):
        return datetime.now().replace(microsecond=0)

    def run(self):
        log.info('Starting gps reading thread.')
        self._running = True

    def stop(self):
        log.info('Stopping gps reading thread.')
        self._running = False

