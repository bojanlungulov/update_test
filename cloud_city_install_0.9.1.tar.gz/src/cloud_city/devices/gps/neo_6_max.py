import _thread
import logging
import time

import pynmea2

from cloud_city.common.constants import TIME_FOR_DECLARING_LOCATION_INVALID

log = logging.getLogger(__name__)


class Neo6Max(object):
    def __init__(self, read_data, clear_data):
        self.read_data = read_data
        self.clear_data = clear_data
        self._location_valid = False
        self._latitude = None
        self._longitude = None
        self._ground_speed = None
        self._timestamp = None
        self._running = False
        self._last_valid_location = time.perf_counter()
        self._lock = _thread.allocate_lock()

    @property
    def location_valid(self):
        with self._lock:
            data = self._location_valid
        return data

    @property
    def latitude(self):
        with self._lock:
            data = self._latitude
        return data

    @property
    def longitude(self):
        with self._lock:
            data = self._longitude
        return data

    @property
    def speed(self):
        with self._lock:
            data = self._ground_speed
        return data

    @property
    def timestamp(self):
        return self._timestamp

    def _parse_data(self, raw_data):
        if raw_data is None:
            return False
        if raw_data == "":
            return False
        if 'RMC' in raw_data:
            log.debug(f'GPS Received data: {raw_data[:-2]}')
            if raw_data.split(',')[2] == 'A':
                data = pynmea2.parse(raw_data)
                with self._lock:
                    self._location_valid = data.is_valid
                    self._latitude = data.latitude
                    self._longitude = data.longitude
                    self._timestamp = data.datetime
                    # Convert to km/h and round as better precision is not required.
                    self._ground_speed = round(float(data.data[6]) * 1.852)
                    self._last_valid_location = time.perf_counter()
                log.debug(f'GPS parsed data: Time: {self._timestamp}, Lat: {self._latitude}, '
                          f'Long: {self._longitude}, Speed: {self._ground_speed}')
                return True
            else:
                return False

    def _reading_thread(self):
        while self._running:
            data = None
            try:
                data = self.read_data().decode(errors='ignore')

                if 'RMC' in data:
                    result = self._parse_data(data)

                    if not result:
                        self._location_valid = False
                        log.warning('GPS Position is not valid.')
                        self.clear_data()
                        log.debug('Cleared serial input buffer.')
                    else:
                        # If location is not updated for more than predefined time period, declare location as invalid.
                        delta = time.perf_counter() - self._last_valid_location
                        if result and delta > TIME_FOR_DECLARING_LOCATION_INVALID:
                            log.error(f'GPS Location is not updated for more than {TIME_FOR_DECLARING_LOCATION_INVALID}'
                                      f' seconds. Declaring location as invalid')
                            self._location_valid = False
            except Exception as e:
                self._location_valid = False
                log.exception(f'GPS Error in parsing received data, data: {data}', e)
                self.clear_data()

    def run(self):
        log.info('GPS starting reading thread.')
        self._running = True
        _thread.start_new_thread(self._reading_thread, ())

    def stop(self):
        log.info('GPS stopping gps reading thread.')
        self._running = False

