import sys

from cloud_city.updater import main

if __name__ == '__main__':
    sys.exit(main(sys.argv[:]))
